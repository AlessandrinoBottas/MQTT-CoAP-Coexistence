import paho.mqtt.client as mqtt
import datetime

BROKER_HOST = "test.mosquitto.org"
BROKER_PORT = 1883

CLIENT_ID = "MaintenanceSubscriberBottazzi"
BROKEN_ACTUATOR_TOPIC   = "progetto/telematica/bottazzi/actuator/maintenance"

def get_current_time():
    current_time = datetime.datetime.now()
    return str(current_time.hour) + ":" + str(current_time.minute) + ":" + str(current_time.second)

def on_connect_callback(client, userdata, flags, rc, properties):
    if rc == 0:
        print(f"Connected to MQTT Broker [{BROKER_HOST}]!")
    else:
        print("Failed to connect, return code %d\n", rc) #rc return code of the "server"
        print("rc values:\n0: Connection successful\n" +
              "1: Connection refused - incorrect protocol version\n" +
              "2: Connection refused - invalid client identifier\n" +
              "3: Connection refused - server unavailable\n" +
              "4: Connection refused - bad username or password\n" +
              "5: Connection refused - not authorised")
        
def on_subscribe_callback(client, userdata, mid, reason_code_list, properties):
    if reason_code_list[0].is_failure:
        print(f"Broker rejected your subscription: {reason_code_list[0]}")
    else:
        print(f"Broker granted your subscription: ")
        print(reason_code_list)

def on_message_callback(client, userdata, msg):
    """
    Print the message recieved from the MQTT broker.

    Args:
        msg: An instance of MQTTMessage, which contains the topic and payload.
    """
    print(get_current_time(), f"Maintenance REQUIRED: {msg.payload.decode()} from TOPIC: {msg.topic}")

if __name__ == '__main__':
    print("Actuator MQTT listening on HOST", BROKER_HOST, "PORT", BROKER_PORT)

    client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, CLIENT_ID)
    client.on_connect = on_connect_callback
    client.on_subscribe = on_subscribe_callback
    client.on_message = on_message_callback
    client.connect(host=BROKER_HOST, port=BROKER_PORT)
    client.subscribe(BROKEN_ACTUATOR_TOPIC, qos=1)
    client.loop_forever()