#SERVER -> client CoAP, publisher MQTT

import paho.mqtt.client as mqtt
from aiocoap import *
import time
import asyncio
import datetime

#URIs and PORTs
BROKER_HOST = "test.mosquitto.org"
BROKER_PORT = 1883
CLIENT_ID = "ServerPublisherBottazzi"
WATER_PUMP_TOPIC        = "progetto/telematica/bottazzi/actuator/values/water_pump"
LIGHT_BULB_TOPIC        = "progetto/telematica/bottazzi/actuator/values/light_bulb"

HUMIDITY_URI = 'coap://127.0.0.1:5683/humidity'
TEMPERATURE_URI = 'coap://127.0.0.1:5683/temperature'
LIGHT_URI = 'coap://127.0.0.1:5683/light'

#threshold
HUMIDITY_THRESHOLD = 50
TEMPERATURE_THRESHOLD = 30 
LIGHT_THRESHOLD = 20

#global var
water_pump = False
light_bulb = False
client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, CLIENT_ID)

def on_connect_callback(client, userdata, flags, rc, properties):
    #ReturnCode from server
    if rc == 0:
        print("_____________________________________________")
        print(f"Connected to MQTT Broker [{BROKER_HOST}]!")
        print("_____________________________________________")
    else:
        print("Failed to connect, return code:", rc)
        print("rc values:\n0: Connection successful\n" +
              "1: Connection refused - incorrect protocol version\n" +
              "2: Connection refused - invalid client identifier\n" +
              "3: Connection refused - server unavailable\n" +
              "4: Connection refused - bad username or password\n" +
              "5: Connection refused - not authorised")

def get_current_time():
    current_time = datetime.datetime.now()
    return str(current_time.hour) + ":" + str(current_time.minute) + ":" + str(current_time.second)

def publish_messages(topic, msg):
    """
    Publishes a message to a given topic.\n
    Args:
        topic (str): The topic to which the message will be published.
        msg (str): The message to be published.
    Returns: 
        None
    Prints:
        A success message if the message is published successfully.
        An error message if the message publication fails, including the failure status.
    """
    global client
    ret = client.publish(topic, msg)
    status = ret[0]
    if status == 0: 
        print("  ", get_current_time(),f"-> Published: \"{msg}\" to Topic: {topic}")
    else:
        print(f"***FAILED TO PUBLISH TO: {topic}, status {status}***") 

async def fetch_resource(uri):
    """
    CoAPs GET implementation
    Args:
        uri: perform the GET request to the uri
    """
    protocol = await Context.create_client_context()
    
    request = Message(code=GET, uri=uri)
    
    try:
        response = await protocol.request(request).response
        return response.payload.decode()
    except Exception as e:
        return f"Errore durante la richiesta: {e}"
    
def light_handler(light):
    """
    Handles the light sensor data and controls the light bulb.

    This function processes the light sensor data and determines whether the light bulb 
    should be turned on or off based on a predefined threshold. It publishes the 
     message to the LIGHT_BULB_TOPIC.

    Args:
        light: The current light intensity value from the sensor.
    """
    global light_bulb, LIGHT_BULB_TOPIC

    if light < LIGHT_THRESHOLD:
        if (light_bulb == False):
            light_bulb = True
            print("   -> Light bulb must be turned ON")
            publish_messages(LIGHT_BULB_TOPIC, str(light_bulb))
    else:
        if(light_bulb == True):
            light_bulb = False
            print("   -> Light bulb must be turned OFF")
            publish_messages(LIGHT_BULB_TOPIC, str(light_bulb))

def pump_handler(humidity, temperature):
    """
    Handles the himidity and temperature sensors data and controls the water pump.

    This function processes the sensorx data and determines whether the water pump 
    should be turned on or off based on a predefined threshold. It publishes the 
     message to the WATER_PUMP_TOPIC.

    Args:
        humidity: The current humidity value from the sensor.
        temperature: the current temperature value from the sensor.
    """
    global water_pump, WATER_PUMP_TOPIC

    if (humidity < HUMIDITY_THRESHOLD) and (temperature > TEMPERATURE_THRESHOLD):
        if(water_pump == False): 
            water_pump = True
            print("   -> Water pump must be turned ON")
            publish_messages(WATER_PUMP_TOPIC, str(water_pump))
    else:
        if(water_pump == True): 
            water_pump = False
            print("   -> Water pump must be turned OFF")
            publish_messages(WATER_PUMP_TOPIC, str(light_bulb))

def print_fetched_datas(temperature, humidity, light):
    """
    Displays temperature, humidity, and light data in a table format.

    Args:
        temp (float): Temperature value.
        humidity (float): Humidity value.
        pressure (float): Pressure value.
    """
    print("+-----------------+-----------+")
    print("| Parameter       |   Value   |")
    print("+-----------------+-----------+")
    print("| Temperature     | {:>5}     |".format(temperature))
    print("| Humidity        | {:>5}     |".format(humidity))
    print("| Light           | {:>5}     |".format(light))
    print("+-----------------+-----------+")

async def main():
    global HUMIDITY_URI,TEMPERATURE_URI, LIGHT_URI

    while(True):
        print(get_current_time(), "Fetching resources...")
        humidity = await fetch_resource(HUMIDITY_URI)
        temperature = await fetch_resource(TEMPERATURE_URI)
        light = await fetch_resource(LIGHT_URI)

        print_fetched_datas(temperature=temperature, humidity=humidity, light=light)

        pump_handler(int(humidity), int(temperature))
        light_handler(int(light))

        print("_____________________________________________________\n")
        time.sleep(30)

if __name__ == "__main__":
    try:
        client.on_connect = on_connect_callback
        client.connect(BROKER_HOST, BROKER_PORT)
        client.loop_start()
        
        asyncio.run(main())
    except KeyboardInterrupt:
        print("Program interrupted")
    finally:
        client.loop_stop()
        client.disconnect()
        print("Disconnected from MQTT Broker")