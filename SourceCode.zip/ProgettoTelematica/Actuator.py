import paho.mqtt.client as mqtt
import random
import datetime

BROKER_HOST = "test.mosquitto.org"
BROKER_PORT = 1883

CLIENT_ID = "ActuatorSubscriberBottazzi"
WATER_PUMP_TOPIC        = "progetto/telematica/bottazzi/actuator/values/water_pump"
LIGHT_BULB_TOPIC        = "progetto/telematica/bottazzi/actuator/values/light_bulb"
BROKEN_ACTUATOR_TOPIC   = "progetto/telematica/bottazzi/actuator/maintenance"

TOPICS = [(WATER_PUMP_TOPIC, 0), (LIGHT_BULB_TOPIC, 0)]

def get_current_time():
    current_time = datetime.datetime.now()
    return str(current_time.hour) + ":" + str(current_time.minute) + ":" + str(current_time.second)

def on_connect_callback(client, userdata, flags, rc, properties):
    if rc == 0:
        print(f"Connected to MQTT Broker [{BROKER_HOST}]!")
    else:
        print("Failed to connect, return code %d\n", rc) #rc return code of the "server"
        print("rc values:\n0: Connection successful\n" +
              "1: Connection refused - incorrect protocol version\n" +
              "2: Connection refused - invalid client identifier\n" +
              "3: Connection refused - server unavailable\n" +
              "4: Connection refused - bad username or password\n" +
              "5: Connection refused - not authorised")
        
def on_subscribe_callback(client, userdata, mid, reason_code_list, properties):
    if reason_code_list[0].is_failure:
        print(f"Broker rejected your subscription: {reason_code_list[0]}")
    elif reason_code_list[1].is_failure:
        print(f"Broker rejected your subscription: {reason_code_list[1]}")
    else:
        print(f"Broker granted your subscription: ")
        print(reason_code_list)

def on_message_callback(client, userdata, msg):
    """
    Callback function to handle incoming messages and control actuators.

    This function is called when a message is received on subscribed topics. It checks the 
    topic of the message and processes it to control the water pump or light bulb accordingly. 
    If the actuator is detected as broken, it publishes a message to indicate the failure.

    Args:
        msg: An instance of MQTTMessage, which contains the topic and payload.

    Returns:
        None

    Prints:
        The status of the water pump or light bulb based on the message payload.
    """
    global WATER_PUMP_TOPIC, LIGHT_BULB_TOPIC
    
    if msg.topic == WATER_PUMP_TOPIC:
        if(msg.payload.decode() == "True"): print(get_current_time(), "Water Pump -> ON")
        else: print(get_current_time(), "Water Pump -> OFF")

        if(isBroken()):
            publish_messages(BROKEN_ACTUATOR_TOPIC, "WATERPUMP BROKEN!!!")
            
    elif msg.topic == LIGHT_BULB_TOPIC:
        if(msg.payload.decode() == "True"): print(get_current_time(), "Light Bulp -> ON")
        else: print(get_current_time(), "Light Bulp -> OFF")

        if(isBroken()):
            publish_messages(BROKEN_ACTUATOR_TOPIC, "LIGHTBULB BROKEN!!!")

def publish_messages(topic, msg):
    """
    Publishes a message to a given topic.\n
    Args:
        topic (str): The topic to which the message will be published.
        msg (str): The message to be published.
    Returns: 
        None
    Prints:
        A success message if the message is published successfully.
        An error message if the message publication fails, including the failure status.
    """
    global client
    ret = client.publish(topic, msg)
    status = ret[0]
    if status == 0: 
        print("  ", get_current_time(),f"-> Published: \"{msg}\" to Topic: {topic}")
    else:
        print(f"***FAILED TO PUBLISH TO: {topic}, status {status}***") 

def isBroken():
    return (random.randint(0,100) < 10)

if __name__ == '__main__':
    print("Actuator MQTT listening on HOST", BROKER_HOST, "PORT", BROKER_PORT)

    client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, CLIENT_ID)
    client.on_connect = on_connect_callback
    client.on_subscribe = on_subscribe_callback
    client.on_message = on_message_callback
    client.connect(host=BROKER_HOST, port=BROKER_PORT)
    client.subscribe(TOPICS)
    client.loop_forever()