from aiocoap import *
from aiocoap import resource
import asyncio
import random
import datetime

def get_current_time():
    current_time = datetime.datetime.now()
    return str(current_time.hour) + ":" + str(current_time.minute) + ":" + str(current_time.second)

class HumidityResource(resource.Resource):
    """
    Satisfy the GET request.
    Print the message he sent on the screen
    """
    async def render_get(self, request):
        humidity = self.get_humidity()
        payload = str(humidity).encode()

        print(get_current_time(), f"HUMIDITY request\t-> value: ", payload.decode())

        return Message(payload=payload)
    
    def get_humidity(self):
        return random.randint(0, 100)
    
class LightResource(resource.Resource):
    """
    Satisfy the GET request.
    Print the message he sent on the screen
    """
    async def render_get(self, request):
        light = self.get_light()
        payload = str(light).encode()

        print(get_current_time(), f"LIGHT request\t\t-> value: ", payload.decode())

        return Message(payload=payload)
    
    def get_light(self):
        return random.randint(0, 100)

class TemperatureResource(resource.Resource):
    """
    Satisfy the GET request.
    Print the message he sent on the screen
    """
    async def render_get(self, request):
        temperature = self.get_temperature()
        payload = str(temperature).encode()

        print(get_current_time(), f"TEMPERATURE request\t-> value: ", payload.decode())

        return Message(payload=payload)
    
    def get_temperature(self):
        return random.randint(-10, 40)

async def main():
    #setting up resources
    root = resource.Site()
    root.add_resource(['humidity'], HumidityResource())
    root.add_resource(['temperature'], TemperatureResource())
    root.add_resource(['light'], LightResource())
    
    bind_address = ("127.0.0.1", 5683)  #localhost
    await Context.create_server_context(root, bind=bind_address)    #asyncronous server 

    print("Sensor CoAP server Running...")
    
    await asyncio.get_running_loop().create_future()                #waiting for requests

if __name__ == "__main__":
    asyncio.run(main())